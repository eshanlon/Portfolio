function TimerCountdown(app, input)
if input == 0
    app.Label.Text = (num2str(str2double(app.Label.Text) - 1));
elseif input == 1
    app.Label.Text = '5';
    app.MemorizeTextArea.Value = '';
end
end