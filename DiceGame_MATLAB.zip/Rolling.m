function ResultRoll = Rolling(DiceNum,Prob)
ResultRoll = [];
for i = 1:DiceNum
    if Prob == 0
        ResultRoll = [ResultRoll, randi(6,1)];
    elseif Prob > 0
        InitialProb = (1:6);
        IncProbArray = setdiff(1:6, [2, 5]);
        NewProb = InitialProb;
        for j = (1:Prob)
            IncProbNum = IncProbArray(randi(numel(IncProbArray),1));
            NewProb = [NewProb,IncProbNum];
        end
        ChooseNum = randi(6+Prob,1);
        DiceVal = NewProb(1,ChooseNum);
        ResultRoll = [ResultRoll,DiceVal];
    else
        InitialProb = (1:6);
        NewProb = InitialProb;
        for j = (1:(Prob*-1))
            DecProbArray = setdiff(NewProb, [2, 5]);
            NumRemove = DecProbArray(randi(numel(DecProbArray)));
            IndexProb = NewProb ~= NumRemove;
            NewProb = NewProb(IndexProb);
        end
            ChooseNum = NewProb(1,randi(numel(NewProb),1));
            ResultRoll = [ResultRoll, ChooseNum];
    end
end
end