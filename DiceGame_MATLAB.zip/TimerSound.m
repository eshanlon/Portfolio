function TimerSound(input)
[y, Fs] = audioread('timer_sound.wav');
TimerS = audioplayer(y, Fs);
if input == 0
    play(TimerS);
elseif input == 1
    stop(TimerS);
end
end